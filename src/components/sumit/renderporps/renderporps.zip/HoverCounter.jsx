import React, { Component } from 'react'

export default function HoverCounter({count,incrementCounter,name}) {
    return (
      <div>
        <h1  onMouseOver={incrementCounter} >Hover {count} times</h1>
      </div>
    )
  }

