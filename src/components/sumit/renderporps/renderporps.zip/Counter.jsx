import React, { Component } from 'react'

export default class Counter extends Component {
    state = {
        count:0
    }
    incrementCounter = ()=> {
        this.setState((prevState)=> ({
            count: prevState.count+1
        }))
    }
    name = ()=> {
        const txt =  'Mohammad Kamrul Hasan';
        return <h2>{txt}</h2>
    }
  render() {
    // const {render} = this.props;
    const {children} = this.props;
    const {count} = this.state

    // return( render(count, this.incrementCounter, this.name)) 
    return children(count, this.incrementCounter, this.name)
  }
}
