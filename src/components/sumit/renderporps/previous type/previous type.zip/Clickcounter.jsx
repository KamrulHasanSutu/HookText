import React, { Component } from 'react'

export default class Clickcounter extends Component {
    state = {
        count:0
    }
    clicked = ()=> {
        this.setState((prevState)=> ({
            count: prevState.count+1
        }))
    }
  render() {
    return (
      <div>
        <button type='button'  onClick={this.clicked}>clicked {this.state.count} times</button>
      </div>
    )
  }
}
