export default function User ({name}){

    return name(false) // sending value of islogged in true(1) / false(0)
    // return name(); // calling funcion
    // return name.charAt(0).toUpperCase()+name.slice(1); // received and resend modified
}