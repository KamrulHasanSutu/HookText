import React, { Component } from 'react'

export default class HoverCounter extends Component {
    state = {
        count:0
    }

    hoverMouse = ()=> {
        this.setState((prevState)=> ({
            count: prevState.count+1
        }))
    }
  render() {
    return (
      <div>
        <h1 type='button'  onMouseOver={this.hoverMouse}>Hover {this.state.count} times</h1>
      </div>
    )
  }
}
